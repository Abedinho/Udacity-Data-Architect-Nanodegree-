
/*Create a DDL and DML SQL script*/	
	
CREATE TABLE Employee (
	EmployeeID VARCHAR(20) PRIMARY KEY,
	EmployeeNumber VARCHAR(20),
	EmployeeName VARCHAR(50),
	HireDate DATE,
    ManagerID INT,
    JobID INT,
    Department_ID INT,
    LocationID INT,
    AddressID INT,
    Location_ID INT,
    ED_ID INT,
    Email VARCHAR(100)
);
    

INSERT INTO Employee(EmployeeID, EmployeeName, Email, HireDate)
SELECT DISTINCT emp_id, emp_nm, email, hire_dt FROM proj_stg;

ALTER TABLE Employee
ALTER COLUMN EmployeeID TYPE VARCHAR(20);

			
CREATE TABLE Job (
	JOB_ID SERIAL PRIMARY KEY,
	JOB_Title VARCHAR(100)
);
			
INSERT INTO Job(JOB_Title)
SELECT DISTINCT job_title FROM proj_stg;



CREATE TABLE Department (
	Department_ID SERIAL PRIMARY KEY,
	JOB_Title INT,
    Department_Name VARCHAR(100),
    Manager_ID INT
);
		
INSERT INTO Department(Department_Name) 
SELECT DISTINCT department_nm FROM proj_stg;
			
CREATE TABLE Salary (
	SalaryID SERIAL PRIMARY KEY,
	EmployeeID INT,
    Salary_Amount DECIMAL,
    StartDate DATE,
    EndDate DATE  
);
			
INSERT INTO Salary(Salary_Amount, StartDate)
SELECT salary, hire_dt FROM proj_stg;

CREATE TABLE Location (
	LocationID SERIAL PRIMARY KEY,
	State VARCHAR(50),
	City VARCHAR(50)
);
		
INSERT INTO Location(State, City)
SELECT DISTINCT state, city FROM proj_stg;

CREATE TABLE Address (
	AddressID SERIAL PRIMARY KEY,
	EmployeeID INT,
    Street VARCHAR(50),
	City VARCHAR(50),
    Line1 VARCHAR(100),
	Line2 VARCHAR(100),
    LocationID INT
);

INSERT INTO Address(Street, Line2, City, Line1)
SELECT DISTINCT location, state, city, address FROM proj_stg;

CREATE TABLE Education_Level (
	ED_ID SERIAL PRIMARY KEY,
	ED_level VARCHAR(50)
);
		
INSERT INTO education_level(ED_level)
SELECT DISTINCT education_lvl FROM proj_stg;

CREATE TABLE Employment_History (
	EmployeeID VARCHAR(20), 
	JobID INT,
    Department_ID INT,
    LocationID INT,
    StartDate DATE,
    EndDate DATE,
    ChangeType VARCHAR(20),
    SalaryID INT,
    ED_ID INT,
    ManagerID VARCHAR(20)
);



CREATE TABLE Audit_log (
	AuditLogID INT PRIMARY KEY, 
	ChangeType VARCHAR(20),
    EntityName VARCHAR(20),
    EmployeeID INT

);

CREATE VIEW manager 
AS SELECT s.emp_id AS manager_id, 
p.manager AS manager_name
FROM proj_stg AS p 
FULL JOIN (SELECT DISTINCT emp_id, emp_nm FROM proj_stg
WHERE emp_nm IN (SELECT DISTINCT manager FROM proj_stg)) AS s
ON p.manager=s.emp_nm;



INSERT INTO Employment_History(EmployeeID, LocationID, Department_ID, SalaryID, ED_ID, JobID, ManagerID,StartDate, EndDate)
SELECT DISTINCT p.emp_id, a.AddressID, d.Department_ID, s.SalaryID, x.ed_id, j.job_id,m.manager_id, p.start_dt, p.end_dt
	FROM proj_stg AS p
	JOIN Employee AS e
	ON e.EmployeeID = p.emp_id
	JOIN Address AS a
	ON a.Street = p.location
	JOIN Department AS d
	ON p.department_nm = d.Department_Name
	JOIN Salary AS s
	ON s.Salary_Amount = p.salary
	JOIN Education_level AS x
	ON x.ED_level = p.education_lvl
	JOIN Job AS j 
	ON j.job_title = p.job_title
	JOIN manager AS m
	ON p.manager = m.manager_name;





--CRUD------------------
	
/*Question 1: Return a list of employees with Job Titles and Department Names*/
	
SELECT e.EmployeeID, j.JOB_Title, d.Department_Name
	FROM Employee AS e
	JOIN Employment_History AS f
	ON e.EmployeeID = f.EmployeeID
	JOIN Job AS j
	ON j.JOB_ID = f.JobID
	JOIN Department AS d
	ON d.Department_ID = f.Department_ID;


/*Question 2: Insert Web Programmer as a new job title*/

INSERT INTO job(job_title) VALUES ('Web Programmer');

/*Question 3: Correct the job title from web programmer to web developer*/

UPDATE job SET job_title='Web Developer' WHERE job_title='Web Programmer';

/*Question 4: Delete the job title Web Developer from the database*/

DELETE FROM job WHERE job_title='Web Developer'

/*Question 5: How many employees are in each department?*/


SELECT d.Department_Name, COUNT(e.EmployeeID)
	FROM department AS d
	JOIN Employment_History AS f
	ON d.Department_ID = f.Department_ID
	JOIN Employee AS e
	ON e.EmployeeID = f.EmployeeID
	GROUP BY d.Department_Name;


/*Question 6: Write a query that returns current and past jobs (include employee name, job title, department, manager name, start and end date for position) for employee Toni Lembeck.*/

WITH cte AS (SELECT DISTINCT m.EmployeeID AS manager_id, m.EmployeeName AS manager 
FROM Employee AS m 
JOIN Employment_History AS w 
ON m.EmployeeID = w.ManagerID)

SELECT DISTINCT e.EmployeeName, j.JOB_Title, d.Department_Name, s.manager, f.StartDate, f.EndDate
	FROM Employee AS e
	JOIN Employment_History AS f
	ON e.EmployeeID = f.EmployeeID
	JOIN department AS d
	ON d.Department_ID = f.Department_ID
	JOIN cte AS s 
	ON s.manager_id = f.ManagerID
	JOIN Job AS j
	ON j.JOB_ID = f.JobID
	WHERE e.EmployeeName = 'Toni Lembeck';
	
